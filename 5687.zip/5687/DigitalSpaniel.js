
cardImagesDict = {'0showBrand':'./images/whellies01.png', 
                '1showBrand':'./images/newspaper02.png',
                '2showWebD':'./images/makerek.png',
                '3showDigiM':'./images/newspaper.png',
                '4showWebD':'./images/rider01.png'
}

cardImagesBespokeHeading =['These are wellies',
                'Make Ideas Happen',
                'mmm Mackrel',
                'Smiley mask face',
            'Riding me bike with me buddies']

cardImagesBespokeText =['Multicoloured and great to wear in the rain',
            'A local paper with big ideas needed A sharp new brand to inspire readers.',
            'in a tin with a long shelf life',
            'Dinamo print stripy top',
        'cycling in a dark place with tunnels and pumpkins']


cardOfficeImages = ['./images/office01.png',
                    './images/office02.png',
                    './images/office03.png',
                    './images/office04.png']

               
//cardBespokeText.map(insertCards)

$(document).ready(function(){
    //navbar link scroll to correct <section> tag
    $(".nav-link").on("click", function(e){
        e.preventDefault();
        var hash = this.hash;
        //console.log($(hash).offset().top)
        $("html, body").animate({scrollTop:$(hash).offset().top},500,function(){
          window.location.hash=hash  
        })
        
    })

    insertCards(cardImagesBespokeHeading,cardImagesBespokeText)
    insertOfficeCards()

 });

function insertCards(cardheading,cardtext){
    $.each(cardImagesDict,function(key,value){  
        firstindex = key[0]  
        cardOverlayText = "<div class='card-img-overlay tooltipDisplay'><span class='tooltiptextList'>"
        cardOverlayText += "<h5 class='card-title whiteColour'>" +  cardheading[firstindex] + "</h5><p class='whiteColour card-text'>" +  cardtext[firstindex] + "</p>"
        $('#insertRecPrjCards').append
        ("<div class='card'><img class='" + key.substring(1) + " cardImgSize' src=" + value + "></img> " + cardOverlayText + "</div>");
    });
};

function insertOfficeCards(){
    $.each(cardOfficeImages,function(index,value){
        $('#insertOfficeCards').append
        ("<div class='card'><img class='cardOfficeSize' src=" + value + "></img></div>");
    });

}

var position = $(document).scrollTop(); 

$(document).scroll(function () {
    var scroll = $(document).scrollTop();
    if(scroll > position){
        //$(".navbar").hide(); 
        $(".navbar").removeClass('sticky-top')
    }else{     
        $(".navbar").addClass('sticky-top') 
        $(".navbar").show(); 
    }
       
});

$('#btnAll').on("click", function(){
    $(".showBrand").show();
    $(".showWebD").show();
    $(".showDigiM").show();
})
$('#btnBrand').on("click", function(){
    $(".showBrand").show();
    $(".showWebD").hide();
    $(".showDigiM").hide();
})
$('#btnWebD').on("click", function(){
    $(".showWebD").show();
    $(".showDigiM").hide();
    $(".showBrand").hide();
})
$('#btnDigM').on("click", function(){
    $(".showDigiM").show();
    $(".showWebD").hide();
    $(".showBrand").hide();
})

