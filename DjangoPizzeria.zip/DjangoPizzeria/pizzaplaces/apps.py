from django.apps import AppConfig


class PizzaplacesConfig(AppConfig):
    name = 'pizzaplaces'
