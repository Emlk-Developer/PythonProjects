from django import forms
from .models import Toppings, Crust


class ToppingsForm(forms.ModelForm):
    class Meta:
        model = Toppings
        fields = ['topping_name']
       
    
class CrustForm(forms.ModelForm):
    
    class Meta:
        model = Crust
        fields = ['crust_type']
        CHOICES=[('select1','select 1'),
         ('select2','select 2')]

 


        

