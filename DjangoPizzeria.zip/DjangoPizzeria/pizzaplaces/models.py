from django.db import models
from django.utils import timezone
from multiselectfield import MultiSelectField

# Create your models here.

class Pizza(models.Model):
    name = models.CharField(max_length=200)
    description = models.CharField(max_length=200, default="tasty")
    
    class Meta:
        managed = True
        db_table = 'all_pizzas'
    
    def __str__(self):
        #returns the string that was entered in the field search
        return '{}'.format(self.name)
    
    
class Toppings(models.Model):
    topping_name = MultiSelectField(choices=self.topping_name)

    
    def __str__(self):
        #returns the string that was entered in the field search
        return '{}'.format(self.topping_name)
    
    #plural of 'Toppings' remains the same but system will write 'searchs'
    #create meta class to hard code the correct pluarlisation
    class Meta:
        verbose_name_plural = 'Toppings'
        managed = True
        db_table = 'all_toppings'
    
class PizzaToppings(models.Model):
    pizza = models.ForeignKey(Pizza, on_delete=models.CASCADE)
    pizza_topping = models.ForeignKey(Toppings, on_delete=models.CASCADE)
    selected_topping = models.BooleanField(default=False)

    
    def __str__(self):
        #returns the string that was entered in the field search
        return '{}'.format(self.pizza_topping, self.pizza)
 
    
class Crust(models.Model):
    crust_type = models.CharField(max_length=50)
    
    def __str__(self):
        #returns the string that was entered in the field search
        return '{}'.format(self.crust_type)
    

class PizzaSize(models.Model):
    size = models.CharField(max_length=50)
    
    def __str__(self):
        #returns the string that was entered in the field search
        return '{}'.format(self.size)
    
class CreatedPizza(models.Model):
    created_pizza = models.CharField(max_length=500)
    created_date = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        #returns the string that was entered in the field search
        return '{}'.format(self.created_date)
