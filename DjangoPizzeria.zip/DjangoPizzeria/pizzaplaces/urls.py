#Defines URL pattern from pizzeriaplaces

from django.urls import path

from . import views

app_name = 'pizzeriaplaces'
urlpatterns = [
    #Home page
    path('home/', views.home, name='home'),
    path('order/<int:pizza_id>/', views.order, name='order'),
    path('createpizza/', views.createpizza , name='createpizza'),
    path('createdpizza/<int:createdId>/', views.createdpizza, name='createdpizza'),
    ]


