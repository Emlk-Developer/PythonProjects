from django.shortcuts import render, redirect
from .models import Pizza, Toppings, PizzaToppings, Crust, PizzaSize, CreatedPizza
from .forms import ToppingsForm, CrustForm
from django.http import HttpResponse



# Create your views here.
def home(request):
    pizza_name = Pizza.objects.all()
    context = {'pizza_name': pizza_name}
    return render(request,'pizzaplaces/home.html', context)


def order(request, pizza_id):
    #show all pizzas
    pizza_name = Pizza.objects.get(id=pizza_id)
    my_pizza = pizza_name.name   
    #toppings = pizza_name.toppings_set.order_by('topping_name')
    
    if request.method == 'POST':
        return HttpResponse("Your pizza is on it's way")
        
    
    pizza_toppings = PizzaToppings.objects.filter(pizza_id=pizza_id)
    context = {'order':my_pizza,'pizza_name':pizza_name, 'pizza_toppings':pizza_toppings}
    return render(request, 'pizzaplaces/order.html',context)



def createpizza(request):
    
    toppings = Toppings.objects.all()
    size = PizzaSize.objects.all()
    crust = Crust.objects.all()  
    
    if request.method == 'POST':
        data = request.POST
        full_pizza = "crust = " + data['crusts'] + " size = " + data['sizes'] + " toppings = " + data['toppings']
        ret = CreatedPizza.objects.create(created_pizza=full_pizza)
        createdId = ret.id


        if ret:
            return redirect('pizzeriaplaces:createdpizza', createdId=createdId)   
        else:
            return HttpResponse("did not work")

    context = {'toppings':toppings,'crust':crust,'size':size}
    return render(request,'pizzaplaces/createpizza.html',context)




def createdpizza(request,createdId):
    
    createdpizzaid = CreatedPizza.objects.get(id=createdId)
    createdpizzadet = createdpizzaid.created_pizza
    createdpizzadate = createdpizzaid.created_date
    createdpizzadateno = createdpizzaid.id
    
    
    context = {'createdpizzadet':createdpizzadet,
               'createdpizzadate':createdpizzadate,
               'createdpizzadateno':createdpizzadateno}
    return render(request,'pizzaplaces/createdpizza.html',context )
